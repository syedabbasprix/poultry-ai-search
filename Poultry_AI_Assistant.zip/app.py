import pandas as pd

try:
    print("Loading Excel file...")
    df = pd.read_excel("POULTRY PRODUCTS REGISTERED.xlsx", sheet_name="poultry ", header=4)
    df = df.rename(columns={"Oral Liquids": "Product Name"})
except Exception as e:
    print("❌ Error loading Excel file:", e)
    exit()

disease_keywords = {
    "CRD": ["enrofloxacin", "tylosin", "oxytetracycline", "colistin"],
    "Coccidiosis": ["toltrazuril", "amprolium", "sulphaquinoxaline"],
    "E.Coli": ["colistin", "enrofloxacin"],
    "Mycoplasma": ["tylosin", "enrofloxacin"],
    "Salmonella": ["enrofloxacin", "amoxicillin"]
}

def search_products(query):
    query = query.lower()
    matches = []
    for _, row in df.iterrows():
        row_text = ' '.join(str(cell).lower() for cell in row.values)
        if query in row_text:
            matches.append(row["Product Name"])
        else:
            for disease, keywords in disease_keywords.items():
                if disease.lower() in query or any(kw in query for kw in keywords):
                    if any(kw in row_text for kw in keywords):
                        matches.append(row["Product Name"])
    return list(set(matches))

def main():
    print("✅ Poultry Product AI Assistant Ready")
    while True:
        query = input("\nEnter your query (or type 'exit' to quit): ")
        if query.lower() == "exit":
            break
        results = search_products(query)
        if results:
            print("\nMatching Products:")
            for result in results:
                print("-", result)
        else:
            print("No matching products found.")

if __name__ == "__main__":
    main()
