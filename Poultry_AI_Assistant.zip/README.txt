Poultry AI Assistant (Offline)

INSTRUCTIONS:
1. Make sure you have Python installed. If not, download it from https://www.python.org/
2. Place this folder anywhere on your computer (like Desktop).
3. Open Command Prompt and navigate to this folder. Example:
   cd Desktop\Poultry_AI_Assistant
4. Run the assistant by typing:
   python app.py

You can now type questions like:
- coccidiosis
- medicine for CRD
- enrofloxacin
